// character.h : header file


class CCharacter : public CObject
{
public:
	CCharacter();
	~CCharacter();

	void CCharacter::Get(CFont *font, char c, BOOL antialias);

	long GetW() { return w; }
	long GetH() { return h; }
	BOOL GetPixel(long x, long y) { return (p[(y*bw)+x/8] & (0x80>>(x%8))) ? TRUE : FALSE; }

private:
	long w, h, bw;
	unsigned char __huge *p;

	void Destroy();
};

