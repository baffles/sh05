// Character.cpp : implementation file
//

#include "stdafx.h"
#include "ttf2pcx.h"
#include "ttf2pcxdlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


CCharacter::CCharacter()
{
	w = h = bw = 0;
	p = NULL;
}



CCharacter::~CCharacter()
{	
	Destroy();
}



void CCharacter::Destroy()
{
	w = h = bw = 0;

	if (p) {
		_hfree(p);
		p = NULL;
	}
}



void CCharacter::Get(CFont *font, char c, BOOL antialias)
{
	Destroy();

	CDC cdc;
	cdc.CreateCompatibleDC(NULL);

	CFont *oldfont = cdc.SelectObject(font);
    char str[2];
    str[0] = c; str[1] = '\0';
    
	CSize size = cdc.GetOutputTextExtent(str, 1);
	if (antialias) {
		size.cx = (size.cx + 7) & 0xFFF8;
		size.cy = (size.cy + 7) & 0xFFF8;
	}

	CBitmap bmp;
	bmp.CreateCompatibleBitmap(&cdc, size.cx*2, size.cy);

	CBitmap *oldbmp = cdc.SelectObject(&bmp);
	
    CRect outline( 0, 0, size.cx*2, size.cy );
    CBrush blackbrush;
    blackbrush.CreateSolidBrush( RGB(0,0,0) );
	cdc.FillRect(outline, &blackbrush);
	cdc.SetTextColor(0xFFFFFFFF);
	int oldmode = cdc.SetBkMode( TRANSPARENT );
	cdc.TextOut(0, 0, str, 1);
    cdc.SetBkMode(oldmode);
	cdc.SelectObject(oldbmp);
	cdc.SelectObject(oldfont);

	BITMAP b;
	
	bmp.GetObject(sizeof(BITMAP), &b);

	w = (long)b.bmWidth;
	h = (long)b.bmHeight;
	bw = (long)b.bmWidthBytes;

	p = (unsigned char __huge *)_halloc(bw*h,sizeof(char));
	bmp.GetBitmapBits(bw*h, p);

	if (c > ' ') {
		while (w > 1) {
			for (long y=0; y<h; y++)
				if (GetPixel(w-2, y))
					goto done;

			w--;
		}
	}

	done:
	if (antialias)
		w = (w + 7) & 0xFFF8;
}

